#!/usr/bin/env python3

import rospy
import numpy as np
from math import pi, cos, sin
from std_msgs.msg import Float64
from geometry_msgs.msg import PoseStamped

class IKSolver:
    def __init__(self):
        rospy.init_node('ik_solver_node', anonymous=True)
        rospy.Subscriber('/command_pose', PoseStamped, self.pose_callback)
        
        self.pub_j1 = rospy.Publisher('/Joint_1/command', Float64, queue_size=1)
        self.pub_j2 = rospy.Publisher('/Joint_2/command', Float64, queue_size=1)
        self.pub_j3 = rospy.Publisher('/Joint_3/command', Float64, queue_size=1)
        self.pub_j4 = rospy.Publisher('/Joint_4/command', Float64, queue_size=1)
        self.pub_j5 = rospy.Publisher('/Joint_5/command', Float64, queue_size=1)

        self.d_list = [0.0435, 0.0, 0.0, 0.0]
        self.a_list = [0.0, 0.140, 0.135, 0.065]
        self.alpha_list = [pi/2, pi, pi, 0]
        
        # INITIAL GUESS: VERTICAL
        # Matches the spawn configuration
        self.q_current = np.array([0.0, 1.57, 0.0, 0.0])

        rospy.loginfo("IK Solver Initialized with Vertical Guess: [0, 1.57, 0, 0]")
        rospy.spin()

    def transformation_func(self, theta, d, a, alpha):
        return np.array([
            [cos(theta), -sin(theta)*cos(alpha),  sin(theta)*sin(alpha), a*cos(theta)],
            [sin(theta),  cos(theta)*cos(alpha), -cos(theta)*sin(alpha), a*sin(theta)],
            [0,           sin(alpha),             cos(alpha),            d],
            [0,           0,                      0,                     1]
        ])

    def forward_kinematics_func(self, theta_list):
        theta_shifted = np.copy(theta_list)
        theta_shifted[1] = theta_shifted[1] + pi/2 
        T_total = np.eye(4)
        for i in range(len(theta_shifted)):
            A = self.transformation_func(theta_shifted[i], self.d_list[i], self.a_list[i], self.alpha_list[i])
            T_total = np.dot(T_total, A)
        return T_total[0:3, 3]

    def get_jacobian(self, q):
        delta = 1e-6
        J = np.zeros((3, 4))
        pos_curr = self.forward_kinematics_func(q)
        for i in range(4):
            q_perturbed = np.copy(q)
            q_perturbed[i] += delta
            pos_new = self.forward_kinematics_func(q_perturbed)
            J[:, i] = (pos_new - pos_curr) / delta
        return J

    def inverse_kinematics_func(self, q0, desired_position):
        q = np.copy(q0)
        for i in range(50):
            current_pos = self.forward_kinematics_func(q)
            error = desired_position - current_pos
            if np.linalg.norm(error) < 1e-4: return q
            J = self.get_jacobian(q)
            inversion = np.linalg.inv(np.dot(J.T, J) + 0.01**2 * np.eye(4))
            q = q + np.dot(np.dot(inversion, J.T), error)
        return q

    def publish_joints(self, q):
        q_norm = np.fmod(q + pi, 2 * pi) - pi 
        self.pub_j1.publish(Float64(q_norm[0]))
        self.pub_j2.publish(Float64(q_norm[1]))
        self.pub_j3.publish(Float64(q_norm[2]))
        self.pub_j4.publish(Float64(q_norm[3]))
        self.pub_j5.publish(Float64(0.0))
        rospy.loginfo(f"IK Result (deg): {np.round(np.degrees(q_norm), 2)}")

    def pose_callback(self, data):
        target = np.array([data.pose.position.x, data.pose.position.y, data.pose.position.z])
        self.q_current = self.inverse_kinematics_func(self.q_current, target)
        self.publish_joints(self.q_current)

if __name__ == '__main__':
    try: IKSolver()
    except rospy.ROSInterruptException: 
      pass
