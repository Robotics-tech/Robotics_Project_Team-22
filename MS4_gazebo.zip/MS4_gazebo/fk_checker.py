#!/usr/bin/env python3

import rospy
import numpy as np
from math import pi, cos, sin
from sensor_msgs.msg import JointState

class FKChecker:
    """
    Subscribes to the robot's /joint_states topic and performs Forward 
    Kinematics (FK) to calculate the actual end-effector position. It includes 
    robust checks to ignore incomplete JointState messages during startup and 
    filters out repeated default position readings.
    """
    def __init__(self):
        # Initialize the node
        rospy.init_node('fk_checker_node', anonymous=True)
        
        # --- SUBSCRIBER ---
        rospy.Subscriber('/joint_states', JointState, self.joint_state_callback)

        # --- DH PARAMETERS (METERS) ---
        # NOTE: These must match the DH parameters used in the IK Solver and URDF.
        self.d_list = [0.0435, 0.0, 0.0, 0.0]
        self.a_list = [0.0, 0.140, 0.135, 0.065]
        self.alpha_list = [pi/2, pi, pi, 0]
        
        # --- JOINT CONFIGURATION ---
        # The list of joint names required for the 4DOF FK calculation.
        self.joint_names_for_fk = ['Joint_1', 'Joint_2', 'Joint_3', 'Joint_4'] 
        
        # Define the default starting position (in mm) to filter out spurious initial readings.
        # This position (X=42.43, Y=-0.0, Z=283.92) was observed in the log.
        self.default_pos_mm = np.array([42.43, -0.0, 283.92])

        rospy.loginfo("FK Checker Node Initialized and listening on /joint_states.")
    
    # ---------------------------------------------------------
    # DH TRANSFORMATION MATRIX
    # ---------------------------------------------------------
    def transformation_func(self, theta, d, a, alpha):
        """Calculates the 4x4 Denavit-Hartenberg transformation matrix."""
        
        c_th = cos(theta)
        s_th = sin(theta)
        c_al = cos(alpha)
        s_al = sin(alpha)
        
        T = np.array([
            [c_th, -s_th*c_al,  s_th*s_al, a*c_th],
            [s_th,  c_th*c_al, -c_th*s_al, a*s_th],
            [0,     s_al,       c_al,      d],
            [0,     0,          0,         1]
        ])
        return T

    # ---------------------------------------------------------
    # FORWARD KINEMATICS
    # ---------------------------------------------------------
    def forward_kinematics_func(self, theta_list):
        """Calculates the end-effector position (X, Y, Z) given joint angles."""
        
        # Create a copy and apply the offset needed for this specific robot's DH table
        theta_shifted = np.copy(theta_list)
        # Assuming Joint_2 requires a pi/2 offset based on previous DH definitions
        theta_shifted[1] = theta_shifted[1] + pi/2 
        
        T_total = np.eye(4)
        for i in range(len(theta_shifted)):
            A = self.transformation_func(theta_shifted[i], self.d_list[i], self.a_list[i], self.alpha_list[i])
            T_total = np.dot(T_total, A)
            
        # The end-effector position is the top-right 3 elements of the final matrix
        return T_total[0:3, 3]

    # ---------------------------------------------------------
    # ROS CALLBACK (Subscriber)
    # ---------------------------------------------------------
    def joint_state_callback(self, data):
        """Called when new joint states are received."""
        
        # 1. ROBUSTNESS CHECK: Ensure all expected joints are present
        if not all(name in data.name for name in self.joint_names_for_fk):
            # Log a warning only once to avoid spamming the terminal during startup
            rospy.logwarn_once("JointState message is missing critical FK joints. Waiting for full data.")
            return

        # 2. EXTRACT JOINT POSITIONS
        q_current = np.zeros(4)
        for i, name in enumerate(self.joint_names_for_fk):
            try:
                # Find the index of the joint in the JointState message
                idx = data.name.index(name)
                q_current[i] = data.position[idx]
            except ValueError:
                # Log an error if a joint is missing despite the initial check (shouldn't happen)
                rospy.logerr(f"CRITICAL: Joint {name} unexpectedly missing after check.")
                return

        # 3. COMPUTE FK
        end_effector_pos = self.forward_kinematics_func(q_current)
        
        # 4. LOG THE RESULT
        # Convert position to millimeters and round for readability
        pos_mm = np.round(end_effector_pos * 1000, 2)
        
        # Filter out the repeating log for the default/ initial position
        if np.allclose(pos_mm, self.default_pos_mm, atol=1.0):
            return
            
        rospy.loginfo(f"FK Check (mm): X={pos_mm[0]}, Y={pos_mm[1]}, Z={pos_mm[2]}")

if __name__ == '__main__':
    try:
        FKChecker()
    except rospy.ROSInterruptException:
        # We don't use rospy.spin() in __init__ as it blocks, so this is 
        # the standard way to run a node with a subscriber in ROS 1.
        # Since FKChecker() does not block, spin() is needed to keep the 
        # process alive and listen for callbacks.
        rospy.spin()
