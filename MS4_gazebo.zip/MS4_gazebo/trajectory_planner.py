#!/usr/bin/env python3

import rospy
import numpy as np
from geometry_msgs.msg import PoseStamped

class TrajectoryPlanner:
    def __init__(self):
        rospy.init_node('trajectory_planner_node', anonymous=True)
        self.pub_pose = rospy.Publisher('/command_pose', PoseStamped, queue_size=10)

        # --- CONFIGURATION (METERS) ---
        
        # 1. START: VERTICAL (Candle Pose)
        # Matches the spawn position (Joint 2 = 90 deg)
        # Z is approx sum of links
        self.X0 = np.array([0.0, 0.0, 0.38]) 
        
        # 2. END: FORWARD & DOWN ("Elbow Down")
        # X = 0.25  (Positive means FORWARD, ensuring "Right Direction")
        # Y = 0.0   (Stay centered)
        # Z = 0.05  (5cm from the floor)
        self.Xf = np.array([0.25, 0.0, 0.05])
        
        self.Tf = 5.0   # Duration (5 seconds)
        self.Ts = 0.1   # Step time
        
        rospy.loginfo("Trajectory Planner Initialized.")
        
        # Wait for Gazebo time
        while rospy.get_time() == 0.0 and not rospy.is_shutdown():
            rospy.sleep(0.01)

    def task_traj(self, X0, Xf, Tf, Ts):
        """Generates linear interpolation path."""
        t = np.arange(0, Tf + Ts, Ts)
        ratio = t / Tf
        x = X0[0] + (Xf[0] - X0[0]) * ratio
        y = X0[1] + (Xf[1] - X0[1]) * ratio
        z = X0[2] + (Xf[2] - X0[2]) * ratio
        return np.vstack((x, y, z))

    def run(self):
        # INTERNAL DELAY
        rospy.loginfo("Waiting 3 seconds for system to stabilize...")
        rospy.sleep(3.0) 
        
        trajectory_points = self.task_traj(self.X0, self.Xf, self.Tf, self.Ts)
        num_steps = trajectory_points.shape[1]
        rate = rospy.Rate(10)
        
        rospy.loginfo(f"Starting Trajectory: Vertical -> Forward/Down ({num_steps} steps).")

        for k in range(num_steps):
            if rospy.is_shutdown(): break
            target_pos = trajectory_points[:, k]
            
            pose_msg = PoseStamped()
            pose_msg.header.stamp = rospy.Time.now()
            pose_msg.header.frame_id = "world" 
            pose_msg.pose.position.x = target_pos[0]
            pose_msg.pose.position.y = target_pos[1]
            pose_msg.pose.position.z = target_pos[2]
            pose_msg.pose.orientation.w = 1.0 
            
            self.pub_pose.publish(pose_msg)
            rospy.loginfo(f"Step {k}: Target (m)={np.round(target_pos, 4)}")
            rate.sleep()
        rospy.loginfo("Trajectory Completed.")
        
if __name__ == '__main__':
    try:
        planner = TrajectoryPlanner()
        planner.run()
    except rospy.ROSInterruptException:
        pass
