clc; clear; close all;

%% === Trajectory Definition ===
X0 = [100  0  80];     % start point
Xf = [180 50 120];     % end point
Tf = 5;                % total time (sec)
Ts = 0.1;              % sample time

% Generate task-space trajectory
Task = task_traj(X0, Xf, Tf, Ts);
N = size(Task, 2);

%% === Allocate joint arrays ===
q1 = zeros(1, N);
q2 = zeros(1, N);
q3 = zeros(1, N);
q4 = zeros(1, N);

q0 = [0; 0; 0; 0];     % initial guess for IK

%% === Loop through each time step ===
for k = 1:N
    X_des = Task(:, k);                   % [x y z] at current time

    q = inverse_kinematics_func(q0, X_des);

    % Store joint values separately
    q1(k) = q(1);
    q2(k) = q(2);
    q3(k) = q(3);
    q4(k) = q(4);

    q0 = q;                                % update guess
end

%% === Display ===
fprintf('IK completed for %d trajectory points\n', N);

%% Optional: plot joint angles
figure;
plot([q1' q2' q3' q4']);
grid on;
xlabel('Time step');
ylabel('Joint angle (rad)');
legend('q1','q2','q3','q4');
title('Joint Angles Over Trajectory');