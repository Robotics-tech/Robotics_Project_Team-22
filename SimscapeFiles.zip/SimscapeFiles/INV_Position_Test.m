% Test script for Inverse Position Kinematics

% Define initial guess for joint angles (in degrees)
initial_guess = deg2rad([30; 0 ; 60 ; 20]);  % Convert to radians

% Define the desired end-effector position (from a known forward kinematics result or Vice Versa)
X_desired = [128; 128; 230];  % Example desired end-effector position in 3D space (X, Y, Z)

% Perform inverse kinematics to find joint angles for the desired position
disp('--- Inverse Kinematics ---');
theta_solution = inverse_kinematics_func(initial_guess, X_desired);  % Compute joint angles
disp('Joint Angles for Desired Position (in degrees):');
disp(rad2deg(theta_solution));  % Convert the output back to degrees for readability

