clc; clear; close all;

%% --- Trajectory Parameters ---
X0 = [110 50 70];       % start point
Xf = [60 10 150];     % end point
Tf = 5;                
Ts = 0.1;              
t = 0:Ts:Tf;

% Generate Cartesian trajectory
Task = task_traj(X0, Xf, Tf, Ts);

%% --- Compute Joint Angles via IK ---
N = length(t);
q1 = zeros(1,N); q2 = zeros(1,N); q3 = zeros(1,N); q4 = zeros(1,N);
q0 = [0;0;0;0];

for k = 1:N
    q = inverse_kinematics_func(q0, Task(:,k));
    q1(k) = q(1); q2(k) = q(2); q3(k) = q(3); q4(k) = q(4);
    q0 = q;
end

%% --- Timeseries for Simscape ---
q1_ts = timeseries(q1, t);
q2_ts = timeseries(q2, t);
q3_ts = timeseries(q3, t);
q4_ts = timeseries(q4, t);
%assignin ('base','t',t)
%assignin ('base','q1_ts',q1_ts);
%assignin ('base','q2_ts',q2_ts);
%assignin ('base','q3_ts',q3_ts);
%assignin ('base','q4_ts',q4_ts);




validate_trajectory(Task, q1, q2, q3, q4);