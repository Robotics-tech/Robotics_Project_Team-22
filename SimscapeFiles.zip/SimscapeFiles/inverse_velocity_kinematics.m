function q_dot = inverse_velocity_kinematics(q, V_F)
    % inverse_velocity_kinematics - Computes the joint velocities for a desired end-effector velocity
    % Input:
    %   q - vector of joint angles (either symbolic or numeric)
    %   V_F - vector of end-effector velocities (either symbolic or numeric)
    % Output:
    %   q_dot - joint velocities (symbolic or numeric)
    
    % Calculate the inverse Jacobian matrix for the given joint angles
    J_inv = inverse_jacobian_matrix(q);
    
    % Compute joint velocities
    if isa(q, 'sym')  % If the input is symbolic
        % Symbolically compute the joint velocities
        q_dot = simplify(J_inv * V_F);
    else  % If the input is numeric
        % Numerically compute the joint velocities
        q_dot = J_inv * V_F;
    end
end