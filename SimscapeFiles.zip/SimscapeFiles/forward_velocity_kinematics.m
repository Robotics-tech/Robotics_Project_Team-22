function V_F = forward_velocity_kinematics(q, q_dot)
    % forward_velocity_kinematics - Computes the forward velocity kinematics
    % Input:
    %   q - vector of joint angles (either symbolic or numeric)
    %   q_dot - vector of joint velocities (either symbolic or numeric)
    % Output:
    %   V_F - end-effector velocity (symbolic or numeric)
    
    % Get the Jacobian matrix
    J = jacobian_matrix(q);
    
    % Compute the forward velocity kinematics
    if isa(q, 'sym')  % If the input is symbolic
        % Symbolically compute the velocity
        V_F = simplify(J * q_dot);
    else  % If the input is numeric
        % Numerically compute the velocity (matrix multiplication)
        V_F = J * q_dot;
    end
end