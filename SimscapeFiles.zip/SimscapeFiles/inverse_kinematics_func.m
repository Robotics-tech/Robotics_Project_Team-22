function theta_solution = inverse_kinematics_func(q0, desired_position)

    theta = q0(:);  % ensure column vector
    desired_position = desired_position(:);

    max_iterations = 200;
    tolerance = 1e-4;  % tighter tolerance for better FK match

    for iter = 1:max_iterations

        % Forward kinematics (handles θ2 shift internally)
        [T_total, ~] = forward_kinematics_func(theta, [43.5; 0; 0; 0], [0; 140; 135; 65], [pi/2; pi; pi; 0]);
        current_position = T_total(1:3,4);

        % Position error
        error = desired_position - current_position;

        % Check convergence
        if norm(error) < tolerance
            disp(['Converged in ', num2str(iter), ' iterations']);
            theta_solution = theta;
            return;
        end

        % Compute Jacobian (handles θ2 shift internally)
        J = jacobian_matrix(theta);

        % Update joint angles using pseudo-inverse
        theta = theta + pinv(J) * error;
    end

    warning('Maximum iterations reached without convergence.');
    theta_solution = theta;
end