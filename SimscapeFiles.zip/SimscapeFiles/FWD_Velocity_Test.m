% Test script for Forward Velocity Kinematics

% Define joint angles (in degrees) and convert to radians
q = deg2rad([45; 0; 90; 45]);  % Convert to radians

% Define joint velocities (in degrees/sec) and convert to radians/sec
q_dot = deg2rad([10; 15; 20; 5]);  % Convert to radians/sec

% Perform forward velocity kinematics
disp('--- Forward Velocity Kinematics ---');
V_F = forward_velocity_kinematics(q, q_dot);  % Compute end-effector velocity
disp('End Effector Velocity:');
disp(vpa(V_F, 4));  % Display the end-effector velocity with higher precision


