function validate_trajectory(Task, q1, q2, q3, q4)

    % DH parameters (same ones used in IK)
    d_list = [43.5; 0; 0; 0];
    a_list = [0; 140; 135; 65];
    alpha_list = [pi/2; pi; pi; 0];

    N = size(Task,2);

    FK_positions = zeros(3, N);
    Error = zeros(3, N);

    for k = 1:N
        theta_list = [q1(k); q2(k); q3(k); q4(k)];

        % Forward kinematics
        [~, pos] = forward_kinematics_func(theta_list, d_list, a_list, alpha_list);

        FK_positions(:,k) = pos;

        % Error between desired and FK
        Error(:,k) = Task(:,k) - pos;
    end

    %% --- Plot comparison ---
    figure;

    subplot(3,1,1);
    plot(Task(1,:), 'LineWidth',1.5); hold on;
    plot(FK_positions(1,:),'--','LineWidth',1.5);
    legend('Desired X','FK X'); grid on; title('X Position');

    subplot(3,1,2);
    plot(Task(2,:), 'LineWidth',1.5); hold on;
    plot(FK_positions(2,:),'--','LineWidth',1.5);
    legend('Desired Y','FK Y'); grid on; title('Y Position');

    subplot(3,1,3);
    plot(Task(3,:), 'LineWidth',1.5); hold on;
    plot(FK_positions(3,:),'--','LineWidth',1.5);
    legend('Desired Z','FK Z'); grid on; title('Z Position');

    figure;
    plot(vecnorm(Error), 'LineWidth',1.5);
    title('FK vs Desired Position Error');
    xlabel('Time step'); ylabel('Error (mm)');
    grid on;

end