% Test script Forward Position Kinematics

% Define the joint angles for forward kinematics (example values)
q = deg2rad([0; 50; 94; 76]);  % Joint angles in radians

% Perform forward kinematics with the given joint angles
disp('--- Forward Kinematics ---');
[T_total, end_effector_position] = forward_kinematics_func(q, [43.5; 0; 0; 0], [0; 140; 135; 65],[pi/2; pi; pi; 0]);
disp('Transformation Matrix:');
disp(vpa(T_total, 4));  % Display transformation matrix with higher precision
disp('End Effector Position (from Forward Kinematics):');
disp(vpa(end_effector_position, 4));  % Display the computed end-effector position with higher precision

