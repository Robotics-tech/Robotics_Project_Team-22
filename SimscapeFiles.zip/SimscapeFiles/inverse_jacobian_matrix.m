function J_inv = inverse_jacobian_matrix(theta_list)
    % inverse_jacobian_matrix - Calculates the inverse (pseudo-inverse) of the Jacobian matrix
    % Inputs:
    %   theta_list - vector of joint angles (either symbolic or numeric)
    % Outputs:
    %   J_inv - Inverse (pseudo-inverse) of the Jacobian matrix
    
    % Define DH parameters for specific robot
    d_list = [43.5; 0; 0; 0];
    a_list = [0; 140; 135; 65];
    alpha_list = [pi/2; pi; pi; 0];

    % Compute the forward kinematics to get the end-effector position
    [~, end_effector_position] = forward_kinematics_func(theta_list, d_list, a_list, alpha_list);

    % Initialize Jacobian matrix
    num_joints = length(theta_list);
    
    if isa(theta_list, 'sym')  % Check if the input is symbolic
        J = sym(zeros(3, num_joints));  % Initialize symbolically
        
        % Compute symbolic derivatives for Jacobian matrix
        for i = 1:num_joints
            J(:, i) = diff(end_effector_position, theta_list(i));
        end
    else  % Numeric input
        J = zeros(3, num_joints);  % Initialize numerically
        
        % Iterate over each joint to calculate the Jacobian numerically
        for i = 1:num_joints
            % Compute the current transformation matrix for joint i
            T_i = transformation_func(theta_list(i), d_list(i), a_list(i), alpha_list(i));
            
            % Compute the position of the end-effector with respect to joint i
            [~, end_effector_position] = forward_kinematics_func(theta_list, d_list, a_list, alpha_list);
            
            % Calculate the Jacobian column for joint i using the transformation matrices
            J(:, i) = end_effector_position - T_i(1:3, 4); % This represents a simple calculation to link position with joint angles
        end
    end
    
    % Simplify the Jacobian matrix (if symbolic)
    if isa(J, 'sym')
        J = simplify(J);
    end

    % Calculate the pseudo-inverse of the Jacobian matrix
    if isa(J, 'sym')
       J_inv = simplify(pinv(J));  % Use pseudo-inverse for underactuated systems
    else
       J_inv = pinv(J);  % Use pseudo-inverse for underactuated systems
    end
end