function Task_Space = task_traj(X0, Xf, Tf, Ts)
% TASK_TRAJ - generates a linear task-space trajectory
%
% Inputs:
%   X0 = [x0 y0 z0] initial point
%   Xf = [xf yf zf] final point
%   Tf = total motion time (sec)
%   Ts = sampling time (sec)
%
% Output:
%   Task_Space = [3 x N] matrix of x,y,z for each time step

    t = 0:Ts:Tf;
    N = length(t);

    % Linear interpolation
    x = X0(1) + (Xf(1) - X0(1)) * (t / Tf);
    y = X0(2) + (Xf(2) - X0(2)) * (t / Tf);
    z = X0(3) + (Xf(3) - X0(3)) * (t / Tf);

    Task_Space = [x; y; z];
end

