function J = jacobian_matrix(theta)

    % DH parameters
    d_list     = [43.5; 0; 0; 0];
    a_list     = [0; 140; 135; 65];
    alpha_list = [pi/2; pi; pi; 0];

    % Apply θ2 shift internally
    theta_shifted = theta;
    theta_shifted(2) = theta_shifted(2) + pi/2;

    n = length(theta_shifted);

    % Origins and z-axes
    p = zeros(3,n+1);
    z = zeros(3,n+1);

    T = eye(4);
    p(:,1) = T(1:3,4);
    z(:,1) = T(1:3,3);

    for i = 1:n
        A = transformation_func(theta_shifted(i), d_list(i), a_list(i), alpha_list(i));
        T = T * A;
        p(:,i+1) = T(1:3,4);
        z(:,i+1) = T(1:3,3);
    end

    pe = p(:,end);
    J = zeros(3,n);

    for i = 1:n
        J(:,i) = cross(z(:,i), (pe - p(:,i)));
    end
end
