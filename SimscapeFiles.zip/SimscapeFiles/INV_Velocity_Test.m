% Test script for Inverse Velocity Kinematics

% Define joint angles (in degrees) and convert to radians
q = deg2rad([30; 30 ; 30; 0]);  % Convert to radians

% Define the desired end-effector velocity (example values in m/s)
V_F = [0.1; 0.2; 0.15];  % Desired velocity components for X, Y, and Z directions

% Perform inverse velocity kinematics to find joint velocities
disp('--- Inverse Velocity Kinematics ---');
q_dot_solution = inverse_velocity_kinematics(q, V_F);  % Compute joint velocities for desired end-effector velocity
disp('Joint Velocities for Desired End Effector Velocity (in Degrees/s):');
disp(vpa(rad2deg(q_dot_solution), 4));  % Display joint velocities with higher precision


