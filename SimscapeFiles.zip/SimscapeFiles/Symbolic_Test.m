% Symbolic Test script for robot kinematic functions

% Define symbolic joint angles and joint velocities
syms q1 q2 q3 q4 q1_dot q2_dot q3_dot q4_dot
q = [q1; q2; q3; q4];
q_dot = [q1_dot; q2_dot; q3_dot; q4_dot];

% Testing forward kinematics
disp('--- Forward Kinematics ---');
[T_total, end_effector_position] = forward_kinematics_func(q, [42.72; 0; 0; 20.47], [0; 120; 0; 0], [pi/2; 0; pi/2; 0]);
disp('Transformation Matrix:');
disp(T_total, 4); % Display with better readability
disp('End Effector Position:');
disp(end_effector_position, 4);

% Testing Jacobian matrix calculation
disp('--- Jacobian Matrix ---');
J = jacobian_matrix(q);
disp('Jacobian Matrix:');
disp(J, 4); % Display with better readability

% Testing forward velocity kinematics
disp('--- Forward Velocity Kinematics ---');
V_F = forward_velocity_kinematics(q, q_dot);
disp('End Effector Velocity:');
disp(V_F, 4);

% Testing inverse Jacobian matrix
disp('--- Inverse Jacobian Matrix ---');
J_inv = inverse_jacobian_matrix(q);
disp('Inverse Jacobian Matrix (J_inv):');
disp(J_inv, 4);

% Testing inverse velocity kinematics
disp('--- Inverse Velocity Kinematics ---');
syms Vx Vy Vz % Desired end-effector velocity components
V_F = [Vx; Vy; Vz];
q_dot_solution = inverse_velocity_kinematics(q, V_F);
disp('Joint Velocities for Desired End Effector Velocity:');
disp(q_dot_solution, 4);


