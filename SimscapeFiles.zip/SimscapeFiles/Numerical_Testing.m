% Numerical Test script for robot kinematic functions

% Define joint angles and joint velocities (input in degrees for angles and degrees/sec for velocities)
q_degrees = [10; 20; 30; 40];  % Joint angles in degrees
q_dot_degrees = [5; 5; 5; 5];  % Joint velocities in degrees/sec

% Convert joint angles from degrees to radians
q = deg2rad(q_degrees);  % Convert degrees to radians

% Convert joint velocities from degrees/sec to radians/sec
q_dot = deg2rad(q_dot_degrees);  % Convert degrees/sec to radians/sec

% Define numerical desired end-effector position for inverse kinematics test
X_desired = [5; 12; 2];  % Desired end-effector position in 3D space (X, Y, Z) [m]

% Initial guess for joint angles (input in degrees)
initial_guess_degrees = [30; 10; 90; 45];  % Initial joint angles in degrees
initial_guess = deg2rad(initial_guess_degrees);  % Convert to radians

% Testing forward kinematics
disp('--- Forward Kinematics ---');
% Forward kinematics function should return a transformation matrix and end effector position
[T_total, end_effector_position] = forward_kinematics_func(q, [42.72; 0; 0; 20.47], [0; 120; 0; 0], [pi/2; 0; pi/2; 0]);
disp('Transformation Matrix:');
disp(T_total);  % Display transformation matrix
disp('End Effector Position:');
disp(end_effector_position);  % Display position

% Testing Jacobian matrix calculation
disp('--- Jacobian Matrix ---');
J = jacobian_matrix(q);  % Compute Jacobian matrix
disp('Jacobian Matrix:');
disp(J);  % Display Jacobian matrix

% Testing forward velocity kinematics
disp('--- Forward Velocity Kinematics ---');
V_F = forward_velocity_kinematics(q, q_dot);  % Compute end effector velocity
disp('End Effector Velocity:');
disp(V_F);  % Display velocity of the end effector

% Testing inverse Jacobian matrix
disp('--- Inverse Jacobian Matrix ---');
J_inv = inverse_jacobian_matrix(J);  % Use the calculated Jacobian
disp('Inverse Jacobian Matrix (J_inv):');
disp(J_inv);  % Display inverse Jacobian

% Testing inverse velocity kinematics
disp('--- Inverse Velocity Kinematics ---');
V_F = [0.1; 0.1; 0.1];  % Desired velocity components for X, Y, Z [m/s]
q_dot_solution = inverse_velocity_kinematics(q, V_F);  % Solve for joint velocities
disp('Joint Velocities for Desired End Effector Velocity:');
disp(q_dot_solution);  % Display joint velocities

% Testing inverse kinematics for position
disp('--- Inverse Kinematics ---');
theta_solution = inverse_kinematics_func(initial_guess, X_desired);  % Compute joint angles for desired position
disp('Joint Angles for Desired Position:');
disp(theta_solution);  % Display computed joint angles for the desired position