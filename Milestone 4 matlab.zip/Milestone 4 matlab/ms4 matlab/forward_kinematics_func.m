function [T_total, end_effector_position] = forward_kinematics_func(theta_list, d_list, a_list, alpha_list)

    % Apply required DH shift for joint 2
    theta_shifted = theta_list;
    theta_shifted(2) = theta_shifted(2) + pi/2;

    T_total = eye(4);

    for i = 1:length(theta_shifted)
        A = transformation_func(theta_shifted(i), d_list(i), a_list(i), alpha_list(i));
        T_total = T_total * A;
    end

    end_effector_position = T_total(1:3,4);
end
